# NoxvexCore — Holographic Core Maximum Glitch V3

This is a visual-focused update to the supplied Flutter project. Existing feature files and route wiring are retained; the holographic overlay is decorative and ignores pointer input.

## Applied visual improvements
- Cyan / electric-blue / violet holographic palette and fine scanlines.
- Brief maximum-glitch bursts with RGB-style echoes and digital tear bands.
- Low-contrast radial energy bloom, orbital node pairs, edge circuit traces, and HUD corner brackets.
- Motion pauses while the app is backgrounded and resumes when foregrounded.
- The overlay respects the platform's reduced-motion / disable-animations preference.
- Effects stay behind an IgnorePointer + ExcludeSemantics layer and do not change authentication or feature logic.

## Verification status
- ZIP integrity: verified after packaging.
- Asset declarations and relative local imports: checked statically for missing paths.
- Flutter analyze, flutter test, and Android APK build: **not run** in this environment because the Flutter/Dart SDK is unavailable. ZIP integrity is not proof that the APK builds. Run `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter build apk --release` in a Flutter-enabled environment before release.

## NoxvexCore Audio Experience (added)
- The uploaded video's audio has been extracted and compressed to a mono MP3 for background music (no video decoding during dashboard playback).
- A shared dashboard audio player loops the music across dashboard feature routes, with play/pause and volume/mute controls.
- Audio pauses when the app is backgrounded and resumes when the app returns if it was playing.
- `audioplayers` was added as a dependency. Run `flutter pub get` before building so `pubspec.lock` is refreshed for the new dependency.

## Follow-up fixes (2026-10-29)
- Fingerprint ring size now scales with the available screen width, with reduced vertical spacing on shorter devices to reduce layout overflow risk.
- Dashboard app bar now displays the bundled `assets/images/logo.png` instead of relying only on a role glyph.
- Splash progress label now describes video playback rather than claiming the app is already ready at 66%; the progress percentage is driven by the actual `splash.mp4` playback position (the supplied clip is approximately 32 seconds).
- When the video cannot initialize, the fallback no longer animates the progress bar to a fake 100% before navigating.
- Flutter/Dart compilation remains unverified in this environment; run the checks above before release.


## Perbaikan layout dan media (29 Oktober 2026)
- Ukuran painter ring sidik jari menggunakan ukuran runtime yang benar (menghindari `const Size` dengan nilai non-konstan).
- Scaffold verifikasi sidik jari tidak mengubah ukuran viewport saat inset sistem muncul.
- Logo dashboard memakai `BoxFit.contain` agar wordmark tidak terpotong pada avatar bulat.
- Splash progress tetap disinkronkan dengan posisi video yang sedang diputar.

Catatan: build APK perlu dijalankan di lingkungan dengan Flutter SDK; arsip ini tidak menyatakan build telah lulus tanpa pengujian tersebut.
